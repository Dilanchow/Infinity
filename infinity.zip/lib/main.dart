import 'package:flutter/material.dart';
import 'package:gyphi/Widgets/Inicio.dart';

void main() => runApp(Start());
