package com.example.gyphi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
